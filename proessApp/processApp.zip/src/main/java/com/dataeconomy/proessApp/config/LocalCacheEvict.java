package com.dataeconomy.proessApp.config;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Component;


//@Component
public class LocalCacheEvict {
    @CacheEvict(cacheNames = "allitemscache",allEntries = true)
    public void evictAllUsersCache() {
    }
}
